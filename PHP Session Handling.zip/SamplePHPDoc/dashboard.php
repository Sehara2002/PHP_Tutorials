<?php
    session_start();

    $recieved_username =  $_SESSION['USERNAME'];

    echo $recieved_username;
?>