<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login here </title>
</head>
<body>
    <form method="post">
        <label for="uname">Username</label>
        <input type="text" name="username" id="uname">

        <br>
        <label for="pword">Password</label>
        <input type="text" name="password" id="pword">

        <br>

        <input type="submit" value="Send Data" name="btnsubmit">
    </form>
</body>
</html>



<?php
    if(isset($_POST['btnsubmit'])){
        $_SESSION['USERNAME'] = $_POST['username'];
        echo "<script>
            location.replace('dashboard.php');
        </script>";
    }
?>

